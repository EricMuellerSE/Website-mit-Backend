Read Me: Wichtige Informationen
         zum Mitgliedsantrag!!!

=================================
>>>   Es gibt separate        <<<
>>>   Unterschriftenlisten    <<<
>>>   für Mitglieder !!!      <<<
=================================

Deine Unterschrift zur Kenntnisnahme
der aktuell gültigen
Datenschutzerklärung,
deiner Fotoerlaubnis und deiner
Verzichtserklärung wird jährlich
auf einer separaten Liste
auf dem Gelände geleistet...

Herzlich willkommen im Team :)